import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CompletedTrainingService {

  private baseURL = "http://localhost:8080/api/phase4";

  // private url1 = "http://localhost:8080/api/phase4-user/user/training";

  // private url2 = "http://localhost:8080/api/phase4-admin/admin/addentry";

  constructor(private http:HttpClient) { }
// url1
  getusers():Observable<any>{
    return this.http.get(`${this.baseURL}-user/user/training`);
  }

//url2
  addtech(value:string):Observable<any>{
    return this.http.get(`${this.baseURL}-admin/admin/addentry/${value}`);
  }
//url3
  removetechnology(minus:string):Observable<any>{
    return this.http.get(`${this.baseURL}-admin/admin/remove/${minus}`);
  }
//url4
  displaytechnology():Observable<any>{
    return this.http.get(`${this.baseURL}-admin/admin/allskills`);
  }

  getcurrent(): Observable<any> {
    return this.http.get(`${this.baseURL}-user/user/current`);
  }
}
