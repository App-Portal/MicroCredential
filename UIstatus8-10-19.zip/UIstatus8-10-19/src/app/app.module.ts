import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { TraineeComponent } from './trainee/trainee.component';
import { MentorComponent } from './mentor/mentor.component';
import { AdminComponent } from './admin/admin.component';
import { CoursesComponent } from './courses/courses.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { TraineeLoginComponent } from './trainee-login/trainee-login.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { TraineeSignupComponent } from './trainee-signup/trainee-signup.component';
import { CurrentTrainingComponent } from './current-training/current-training.component';
import { CompletedTrainingComponent } from './completed-training/completed-training.component';
import { EditSkillComponent } from './edit-skill/edit-skill.component';
import { CompletedTrainingMentorComponent } from './completed-training-mentor/completed-training-mentor.component';
import { CurrentTrainingTraineeComponent } from './current-training-trainee/current-training-trainee.component';
import { MainDashboardComponent } from './main-dashboard/main-dashboard.component';
import { ProfileComponent } from './profile/profile.component';
import { PaymentComponent } from './payment/payment.component';
import { HttpClientModule } from '@angular/common/http';
import { AdminEditTechComponent } from './admin-edit-tech/admin-edit-tech.component';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    TraineeComponent,
    MentorComponent,
    AdminComponent,
    CoursesComponent,
    AdminLoginComponent,
    MentorLoginComponent,
    TraineeLoginComponent,
    MentorSignupComponent,
    TraineeSignupComponent,
    CurrentTrainingComponent,
    CompletedTrainingComponent,
    EditSkillComponent,
    CompletedTrainingMentorComponent,
    CurrentTrainingTraineeComponent,
    MainDashboardComponent,
    ProfileComponent,
    PaymentComponent,
    AdminEditTechComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
