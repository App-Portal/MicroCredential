package org.phase3;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Admin extends User {

	@Id
	private Long adminId;

	private String adminName;

	public Admin() {
		super();
	}

	public Admin(Long adminId, String adminName) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
	}

	public Long getAdminId() {
		return adminId;
	}

	public void setAdminId(Long adminId) {
		this.adminId = adminId;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	
}