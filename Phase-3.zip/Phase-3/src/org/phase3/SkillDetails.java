package org.phase3;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class SkillDetails {

	@Id
	private Long mentorId;

	private String skillName = "";

	private String toc = "";

	private String prerequisities = "";

	public SkillDetails() {
		super();
	}

	public SkillDetails(Long mentorId, String skillName, String toc, String prerequisities) {
		super();
		this.mentorId = mentorId;
		this.skillName = skillName;
		this.toc = toc;
		this.prerequisities = prerequisities;
	}

	public Long getMentorId() {
		return mentorId;
	}

	public void setMentorId(Long mentorId) {
		this.mentorId = mentorId;
	}

	public String getSkillName() {
		return skillName;
	}

	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}

	public String getToc() {
		return toc;
	}

	public void setToc(String toc) {
		this.toc = toc;
	}

	public String getPrerequisities() {
		return prerequisities;
	}

	public void setPrerequisities(String prerequisities) {
		this.prerequisities = prerequisities;
	}

}
