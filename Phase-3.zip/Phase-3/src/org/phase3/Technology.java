package org.phase3;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Technology {

	@Id
	private Long technologyId;

	private String technologyName;

	public Technology() {
		super();
	}

	public Technology(Long technologyId, String technologyName) {
		super();
		this.technologyId = technologyId;
		this.technologyName = technologyName;
	}

	public Long getTechnologyId() {
		return technologyId;
	}

	public void setTechnologyId(Long technologyId) {
		this.technologyId = technologyId;
	}

	public String getTechnologyName() {
		return technologyName;
	}

	public void setTechnologyName(String technologyName) {
		this.technologyName = technologyName;
	}

}