package com.example.demo;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;


@Entity
public class Usertraining {

	@Id
	private Integer trainingid;
 	
//	@OneToOne
//	@JoinColumn(name="myuserid")
	private Integer userid;//FOREIGN KEY from User profile
	
    private String trainername;
    
    private String course;
    
    private Integer completion;
    
    private Boolean status;
    
	public Usertraining() {
		super();
	}

	public Usertraining(Integer userid, String trainername, String course, Integer completion, Boolean status) {
		super();
		this.userid = userid;
		this.trainername = trainername;
		this.course = course;
		this.completion = completion;
		this.status = status;
	}

	public Integer getTrainingid() {
		return trainingid;
	}

	public void setTrainingid(Integer trainingid) {
		this.trainingid = trainingid;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getTrainername() {
		return trainername;
	}

	public void setTrainername(String trainername) {
		this.trainername = trainername;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public Integer getCompletion() {
		return completion;
	}

	public void setCompletion(Integer completion) {
		this.completion = completion;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

    
}
