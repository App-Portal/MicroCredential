package com.example.demo;
import org.springframework.data.repository.CrudRepository;

public interface Userprofilerepository extends CrudRepository<Userprofile, Integer> {

}
