package com.example.demo;

import javax.validation.Valid;

import org.springframework.data.repository.CrudRepository;

public interface Mentorprofilerep extends CrudRepository<Mentorprofile, Integer> {



}
