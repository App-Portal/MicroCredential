package com.example.user;

import javax.persistence.*;

@Entity
public class Userprofile {

	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private Integer myuserid;
    
    private String username;
    
    private String password;
    
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="role")
    private Role role;

	public Userprofile() {
		super();
	}

	public Userprofile(String firstname, String lastname, String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}

	public Integer getMyuserid() {
		return myuserid;
	}

	public void setMyuserid(Integer myuserid) {
		this.myuserid = myuserid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
