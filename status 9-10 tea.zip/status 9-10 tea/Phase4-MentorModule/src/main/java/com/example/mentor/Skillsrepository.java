package com.example.mentor;

import org.springframework.data.repository.CrudRepository;



public interface Skillsrepository extends CrudRepository<Skills, Integer>  {

}
