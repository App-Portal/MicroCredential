package com.example.demo;
import org.springframework.data.repository.CrudRepository;

import com.example.demo.Authorization;

public interface Authorizationrepository extends CrudRepository<Authorization, Integer> {

}
