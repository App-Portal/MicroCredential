package com.example.demo;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller    
@RequestMapping(value= {"/admin"}) // This means URL's start with /demo (after Application path)
public class Skillcontroller {
	
	
	@Autowired 
	private Skillsrepository Srep;
	
	
	@PostMapping(value= {"/addentry"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody String addNew (@Valid @RequestBody Skills sk) {
		
		Srep.save(sk);
		return "Saved";
	}

//	@RequestMapping(value= {"/"}) 
//	public @ResponseBody String addNewUser () {
////		Map<Integer,String> person = new HashMap<Integer,String>();
//		
//		Rrep.save(new Role(1,"Admin"));
//		Rrep.save(new Role(2,"Mentor"));
//		Rrep.save(new Role(3,"User"));
//
//		return "Saved";
//	}
	
//	@GetMapping(value= {"/all"})
//	public @ResponseBody Iterable<Authorization> getAllUsers() {
//		return Arep.findAll();
//	}
}
