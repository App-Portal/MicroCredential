package com.example.demo;

import org.springframework.data.repository.CrudRepository;
import com.example.demo.Skills;

public interface Skillsrepository extends CrudRepository<Skills,Integer> {

}
