import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-current-training',
  templateUrl: './current-training.component.html',
  styleUrls: ['./current-training.component.css']
})
export class CurrentTrainingComponent implements OnInit {

  constructor(private httpservice : HttpClient) { }
  technology : string[];
  ptr : number = 0;
  ngOnInit() {

    this.httpservice.get('../../assets/currenttrainingstrainee.json').subscribe(

      data=>{
        this.technology = data as string[];
      },
      (err : HttpErrorResponse) => {
        console.log(err.message);
      }
    )
    }
}
