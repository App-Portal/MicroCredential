import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-completed-training-mentor',
  templateUrl: './completed-training-mentor.component.html',
  styleUrls: ['./completed-training-mentor.component.css']
})
export class CompletedTrainingMentorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
