import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentTrainingTraineeComponent } from './current-training-trainee.component';

describe('CurrentTrainingTraineeComponent', () => {
  let component: CurrentTrainingTraineeComponent;
  let fixture: ComponentFixture<CurrentTrainingTraineeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CurrentTrainingTraineeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrentTrainingTraineeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
