package com.example.mentor;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Skills {
	@Id
	private int skillid;
	private String skillname;
	
	public Skills() {
		super();
	}
	
	public Skills(int skillid, String skillname) {
		super();
		this.skillid = skillid;
		this.skillname = skillname;
	}

	public int getSkillid() {
		return skillid;
	}

	public void setSkillid(int skillid) {
		this.skillid = skillid;
	}

	public String getSkillname() {
		return skillname;
	}

	public void setSkillname(String skillname) {
		this.skillname = skillname;
	}
	

}
