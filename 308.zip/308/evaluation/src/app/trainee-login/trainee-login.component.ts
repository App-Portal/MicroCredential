import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trainee-login',
  templateUrl: './trainee-login.component.html',
  styleUrls: ['./trainee-login.component.css']
})
export class TraineeLoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
