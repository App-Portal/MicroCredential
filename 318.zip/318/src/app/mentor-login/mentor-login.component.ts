import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-mentor-login',
  templateUrl: './mentor-login.component.html',
  styleUrls: ['./mentor-login.component.css']
})
export class MentorLoginComponent implements OnInit {

  email:string;
  pass:string;

  constructor(private userlogin: Router) { }

  ngOnInit() {
  }
  submit(){
    if(this.email==null){
      alert("enter valid mail address");
    }
    
    else if(this.pass==null){
      alert("enter password");
    }
    else{
      this.userlogin.navigate(['/mentor']);
    }

  }

}
