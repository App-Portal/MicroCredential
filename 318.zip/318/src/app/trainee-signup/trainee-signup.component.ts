import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trainee-signup',
  templateUrl: './trainee-signup.component.html',
  styleUrls: ['./trainee-signup.component.css']
})
export class TraineeSignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
