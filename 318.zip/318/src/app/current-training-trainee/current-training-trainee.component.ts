import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-current-training-trainee',
  templateUrl: './current-training-trainee.component.html',
  styleUrls: ['./current-training-trainee.component.css']
})
export class CurrentTrainingTraineeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
