import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { TraineeLoginComponent } from './trainee-login/trainee-login.component';
import { CurrentTrainingComponent } from './current-training/current-training.component';
import { CompletedTrainingComponent } from './completed-training/completed-training.component';
import { CompletedTrainingMentorComponent } from './completed-training-mentor/completed-training-mentor.component';
import { EditSkillComponent } from './edit-skill/edit-skill.component';
import { CurrentTrainingTraineeComponent } from './current-training-trainee/current-training-trainee.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { TraineeSignupComponent } from './trainee-signup/trainee-signup.component';
import { MentorComponent } from './mentor/mentor.component';
import { TraineeComponent } from './trainee/trainee.component';
import { AdminComponent } from './admin/admin.component';
import { MainDashboardComponent } from './main-dashboard/main-dashboard.component';
import { CoursesComponent } from './courses/courses.component';
import { ProfileComponent } from './profile/profile.component';
import { PaymentComponent } from './payment/payment.component';


const routes: Routes = [
{path:'',component:MainDashboardComponent},
{path:'traineeLogin',component:TraineeLoginComponent},
{path:'home',component:HomeComponent},
{path:'course',component:CoursesComponent},
{path:'currentTraining',component:CurrentTrainingComponent},
{path:'completedTraining',component:CompletedTrainingComponent},
{path:'completedTrainingsMentor',component:CompletedTrainingMentorComponent},
{path:'editSkill',component:EditSkillComponent},
{path:'currentTrainingsMentor',component:CurrentTrainingTraineeComponent},
{path:'mentorLogin',component:MentorLoginComponent},
{path:'adminLogin',component:AdminLoginComponent},
{path:'signupMentor',component:MentorSignupComponent},
{path:'signupTrainee',component:TraineeSignupComponent},
{path:'mentor',component:MentorComponent},
{path:'trainee',component:TraineeComponent},
{path:'signinAdmin',component:AdminComponent},
{path:'profile',component:ProfileComponent},
{path:'payment',component:PaymentComponent},
{path:'admin',component:AdminComponent}];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
